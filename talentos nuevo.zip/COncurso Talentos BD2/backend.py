import os
import json
import asyncio
from datetime import datetime
from typing import List, Optional, Dict, Any
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, status, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, HTMLResponse, Response, StreamingResponse
from pydantic import BaseModel, Field, BeforeValidator
from typing_extensions import Annotated

import motor.motor_asyncio
import redis.asyncio as redis

MONGO_URL = "mongodb://localhost:27017"
DB_NAME = "talentos_db"
REDIS_URL = "redis://localhost:6379"

mongoClient = None
redisClient = None
db = None

dashboardQueues: List[asyncio.Queue] = []

@asynccontextmanager
async def manageSystemLifecycle(app: FastAPI):
    global mongoClient, redisClient, db
    print("--- INICIANDO SISTEMA ---")
    
    mongoClient = motor.motor_asyncio.AsyncIOMotorClient(MONGO_URL)
    db = mongoClient[DB_NAME]
    redisClient = redis.from_url(REDIS_URL, encoding="utf-8", decode_responses=True)
    
    await db.votos_log.create_index([("id_usuario", 1), ("id_concursante", 1)], unique=True)
    await db.concursantes.create_index([("total_votos", -1)])
    await db.usuarios.create_index([("username", 1)], unique=True)

    defaultUsers = [
        {"username": "admin", "password": "123", "rol": "admin"},
        {"username": "juan", "password": "123", "rol": "publico"},
        {"username": "maria", "password": "123", "rol": "publico"}
    ]
    
    print("Verificando usuarios...")
    for user in defaultUsers:
        await db.usuarios.update_one(
            {"username": user["username"]}, 
            {"$set": user}, 
            upsert=True
        )
    print("Usuarios listos. (Admin pass: 123)")

    try:
        yield
    finally:
        print("--- APAGANDO SISTEMA ---")
        mongoClient.close()
        await redisClient.aclose()

app = FastAPI(title="Talent Contest API", version="4.0.0", lifespan=manageSystemLifecycle)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], 
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

staticPath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
if not os.path.exists(staticPath):
    os.makedirs(staticPath)
app.mount("/static", StaticFiles(directory=staticPath), name="static")

@app.get("/favicon.ico", include_in_schema=False)
async def getFavicon(): return Response(content=b"", media_type="image/x-icon")

@app.get("/", response_class=HTMLResponse)
async def serveInterface():
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "interfaz.html")
    if os.path.exists(path): return FileResponse(path)
    return HTMLResponse("<h1>Error: No se encuentra el archivo interfaz.html</h1>")

PyObjectId = Annotated[str, BeforeValidator(str)]

class BaseContestant(BaseModel):
    id: str = Field(..., alias="_id") 
    nombre_completo: str
    categoria: str
    url_foto: str

class PublicContestant(BaseContestant):
    pass

class AdminContestant(BaseContestant):
    total_votos: int = 0

class VoteRequest(BaseModel):
    id_usuario: str
    id_concursante: str

class LoginCredentials(BaseModel):
    username: str
    password: str

async def notifyDashboard():
    if not dashboardQueues:
        return 
        
    data = await getRealtimeDashboard()
    message = json.dumps(data)
    
    for queue in dashboardQueues:
        await queue.put(message)

@app.post("/auth/login", tags=["Autenticacion"])
async def login(credentials: LoginCredentials):
    user = await db.usuarios.find_one({"username": credentials.username, "password": credentials.password})
    if not user: raise HTTPException(status_code=401, detail="Credenciales no válidas")
    return {"username": user["username"], "rol": user["rol"], "id": str(user["_id"])}

@app.post("/auth/register", tags=["Autenticacion"])
async def register(credentials: LoginCredentials):
    if await db.usuarios.find_one({"username": credentials.username}):
        raise HTTPException(status_code=400, detail="Usuario ya existe")
    await db.usuarios.insert_one({"username": credentials.username, "password": credentials.password, "rol": "publico"})
    return {"mensaje": "Usuario creado"}

@app.get("/public/concursantes", response_model=List[PublicContestant], tags=["Publico"])
async def getContestants():
    return await db.concursantes.find().to_list(1000)

@app.post("/public/votar", tags=["Publico"])
async def vote(request: VoteRequest):
    if await db.votos_log.find_one({"id_usuario": request.id_usuario, "id_concursante": request.id_concursante}):
        raise HTTPException(status_code=400, detail="Ya has votado por este participante")

    if not await db.concursantes.find_one({"_id": request.id_concursante}):
        raise HTTPException(status_code=404, detail="Concursante no encontrado")

    await db.votos_log.insert_one({
        "fecha_hora": datetime.now(),
        "id_usuario": request.id_usuario,
        "id_concursante": request.id_concursante
    })
    await db.concursantes.update_one({"_id": request.id_concursante}, {"$inc": {"total_votos": 1}})
    
    await redisClient.incr(f"votos:{request.id_concursante}")

    asyncio.create_task(notifyDashboard())

    return {"mensaje": "Voto registrado"}

@app.post("/admin/cargar-bd", tags=["Administracion"])
async def loadDatabase(data: List[Dict[str, Any]]):
    print(f"Cargando {len(data)} registros...")
    await db.concursantes.delete_many({})
    await db.votos_log.delete_many({})
    
    async for key in redisClient.scan_iter("votos:*"):
        await redisClient.delete(key)

    listDocs = []
    for i, item in enumerate(data, 1):
        idStr = str(item.get("id", item.get("_id", f"auto_{i}")))
        name = item.get("nombre") or item.get("nombre_completo") or f"Participante {i}"
        category = item.get("categoria", "General")
        photoRaw = item.get("foto") or item.get("url_foto") or ""
        fileName = photoRaw.split(".")[0] if photoRaw else ""
        finalPhoto = f"/static/{fileName}.png" if fileName else "/static/default.png"

        listDocs.append({
            "_id": idStr,
            "nombre_completo": name,
            "categoria": category,
            "url_foto": finalPhoto,
            "total_votos": 0
        })

    if listDocs: await db.concursantes.insert_many(listDocs)
    
    asyncio.create_task(notifyDashboard())
    
    return {"mensaje": "Carga exitosa"}

@app.post("/admin/nuevo-participante", tags=["Administracion"])
async def addContestant(contestant: AdminContestant):
    data = contestant.model_dump(by_alias=True)
    data["total_votos"] = 0
    if not data["url_foto"] or len(data["url_foto"]) < 3: data["url_foto"] = "/static/default.png"
    
    try:
        await db.concursantes.insert_one(data)
        asyncio.create_task(notifyDashboard())
        
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error: {str(e)}")
    return {"mensaje": "Registrado"}

@app.get("/admin/dashboard-realtime", tags=["Administracion"])
async def getRealtimeDashboard():
    contestants = await db.concursantes.find().to_list(1000)
    ranking = []
    total = 0
    for c in contestants:
        cId = str(c["_id"])
        redisVotes = await redisClient.get(f"votos:{cId}")
        votes = int(redisVotes) if redisVotes else 0
        
        total += votes
        ranking.append({"id": cId, "nombre": c["nombre_completo"], "foto": c["url_foto"], "votos": votes})
    
    ranking.sort(key=lambda x: x["votos"], reverse=True)
    return {"total_global_votos": total, "detalle": ranking}

@app.get("/admin/events")
async def streamEvents(request: Request):
    async def eventGenerator():
        queue = asyncio.Queue()
        dashboardQueues.append(queue)
        try:
            initialData = await getRealtimeDashboard()
            yield f"data: {json.dumps(initialData)}\n\n"
            
            while True:
                if await request.is_disconnected():
                    break
                
                data = await queue.get()
                yield f"data: {data}\n\n"
        except asyncio.CancelledError:
            pass
        finally:
            dashboardQueues.remove(queue)

    return StreamingResponse(eventGenerator(), media_type="text/event-stream")

@app.get("/admin/top-3", tags=["Reportes"])
async def getTop3():
    pipeline = [{"$sort": {"total_votos": -1}}, {"$limit": 3}, {"$project": {"_id": 1, "nombre_completo": 1, "categoria": 1, "url_foto": 1, "total_votos": 1}}]
    return await db.concursantes.aggregate(pipeline).to_list(3)

@app.get("/admin/votos-por-categoria", tags=["Reportes"])
async def getVotesByCategory():
    pipeline = [{"$group": {"_id": "$categoria", "total_votos_categoria": {"$sum": "$total_votos"}, "cantidad_participantes": {"$sum": 1}}}, {"$sort": {"total_votos_categoria": -1}}]
    return await db.concursantes.aggregate(pipeline).to_list(100)

@app.get("/admin/sin-votos", tags=["Reportes"])
async def getNoVotes():
    return await db.concursantes.find({"total_votos": 0}).to_list(1000)

if __name__ == "__main__":
    import uvicorn
    print("\n================================================================")
    print("  Abre: http://127.0.0.1:8000")
    print("================================================================\n")
    uvicorn.run(app, host="127.0.0.1", port=8000)