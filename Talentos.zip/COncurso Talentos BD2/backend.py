import os
from datetime import datetime
from typing import List, Optional, Dict, Any
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, status, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, HTMLResponse, Response
from pydantic import BaseModel, Field, BeforeValidator
from typing_extensions import Annotated

import motor.motor_asyncio
import redis.asyncio as redis

# --- CONFIGURACIÓN ---
MONGO_URL = "mongodb://localhost:27017"
DB_NAME = "talentos_db"
REDIS_URL = "redis://localhost:6379"

mongo_client = None
redis_client = None
db = None

@asynccontextmanager
async def gestionar_ciclo_vida_sistema(app: FastAPI):
    global mongo_client, redis_client, db
    print("--- INICIANDO SISTEMA ---")
    
    # Conexión a Base de Datos
    mongo_client = motor.motor_asyncio.AsyncIOMotorClient(MONGO_URL)
    db = mongo_client[DB_NAME]
    redis_client = redis.from_url(REDIS_URL, encoding="utf-8", decode_responses=True)
    
    # Crear índices
    await db.votos_log.create_index([("id_usuario", 1), ("id_concursante", 1)], unique=True)
    await db.concursantes.create_index([("total_votos", -1)])
    # Índice para asegurar que no haya dos usuarios con el mismo nombre
    await db.usuarios.create_index([("username", 1)], unique=True)

    # Usuarios por defecto
    usuarios_por_defecto = [
        {"username": "admin", "password": "123", "rol": "admin"},
        {"username": "juan", "password": "123", "rol": "publico"},
        {"username": "maria", "password": "123", "rol": "publico"}
    ]
    
    print("Verificando usuarios...")
    for usuario in usuarios_por_defecto:
        await db.usuarios.update_one(
            {"username": usuario["username"]}, 
            {"$set": usuario}, 
            upsert=True
        )
    print("Usuarios listos. (Admin pass: 123)")

    try:
        yield
    finally:
        print("--- APAGANDO SISTEMA ---")
        mongo_client.close()
        await redis_client.aclose()

app = FastAPI(
    title="Talent Contest API",
    version="3.2.0", 
    lifespan=gestionar_ciclo_vida_sistema
)

# Configuración CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], 
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- CONFIGURACIÓN DE IMÁGENES (STATIC) ---
path_static = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
if not os.path.exists(path_static):
    os.makedirs(path_static)

app.mount("/static", StaticFiles(directory=path_static), name="static")

@app.get("/favicon.ico", include_in_schema=False)
async def favicon():
    return Response(content=b"", media_type="image/x-icon")

@app.get("/", response_class=HTMLResponse)
async def servir_interfaz():
    path_actual = os.path.dirname(os.path.abspath(__file__))
    path_archivo = os.path.join(path_actual, "interfaz.html")
    
    if os.path.exists(path_archivo):
        return FileResponse(path_archivo)
    else:
        return HTMLResponse("<h1>Error: No se encuentra el archivo interfaz.html</h1>")

# --- MODELOS DE DATOS ---
PyObjectId = Annotated[str, BeforeValidator(str)]

class ModeloBaseConcursante(BaseModel):
    id: str = Field(..., alias="_id") 
    nombre_completo: str
    categoria: str
    url_foto: str

class VistaConcursantePublico(ModeloBaseConcursante):
    pass

class VistaConcursanteAdministrador(ModeloBaseConcursante):
    total_votos: int = 0

class SolicitudDeVoto(BaseModel):
    id_usuario: str
    id_concursante: str

class CredencialesLogin(BaseModel):
    username: str
    password: str

# --- ENDPOINTS ---

@app.post("/auth/login", tags=["Autenticacion"])
async def autenticar_usuario_sistema(credenciales: CredencialesLogin):
    usuario_encontrado = await db.usuarios.find_one({
        "username": credenciales.username, 
        "password": credenciales.password
    })
    
    if not usuario_encontrado:
        raise HTTPException(status_code=401, detail="Credenciales no válidas")
    
    return {
        "username": usuario_encontrado["username"], 
        "rol": usuario_encontrado["rol"], 
        "id": str(usuario_encontrado["_id"])
    }

# === NUEVO ENDPOINT DE REGISTRO ===
@app.post("/auth/register", tags=["Autenticacion"])
async def registrar_usuario_nuevo(credenciales: CredencialesLogin):
    # 1. Verificar si el usuario ya existe
    if await db.usuarios.find_one({"username": credenciales.username}):
        raise HTTPException(status_code=400, detail="El nombre de usuario ya está en uso")
    
    # 2. Crear el usuario (Rol por defecto: publico)
    nuevo_usuario = {
        "username": credenciales.username,
        "password": credenciales.password,
        "rol": "publico"
    }
    
    await db.usuarios.insert_one(nuevo_usuario)
    return {"mensaje": "Usuario creado exitosamente"}

@app.get("/public/concursantes", response_model=List[VistaConcursantePublico], tags=["Publico"])
async def recuperar_catalogo_concursantes_vista_publica():
    return await db.concursantes.find().to_list(1000)

@app.post("/public/votar", tags=["Publico"])
async def procesar_voto_concursante(solicitud: SolicitudDeVoto):
    voto_existente = await db.votos_log.find_one({
        "id_usuario": solicitud.id_usuario,
        "id_concursante": solicitud.id_concursante
    })
    
    if voto_existente:
        raise HTTPException(status_code=400, detail="Ya has votado por este participante")

    concursante_objetivo = await db.concursantes.find_one({"_id": solicitud.id_concursante})
    if not concursante_objetivo:
        raise HTTPException(status_code=404, detail="Concursante no encontrado")

    await db.votos_log.insert_one({
        "fecha_hora": datetime.now(),
        "id_usuario": solicitud.id_usuario,
        "id_concursante": solicitud.id_concursante
    })

    await db.concursantes.update_one({"_id": solicitud.id_concursante}, {"$inc": {"total_votos": 1}})
    await redis_client.incr(f"votos:{solicitud.id_concursante}")

    return {"mensaje": "Voto registrado correctamente"}

@app.post("/admin/cargar-bd", tags=["Administracion"])
async def restaurar_base_datos_concursantes(datos_carga: List[Dict[str, Any]]):
    print(f"Procesando carga de {len(datos_carga)} registros...")
    
    await db.concursantes.delete_many({})
    await db.votos_log.delete_many({})
    
    claves_redis = await redis_client.keys("votos:*")
    if claves_redis:
        await redis_client.delete(*claves_redis)

    lista_documentos = []
    contador = 0

    for item in datos_carga:
        contador += 1
        
        identificador = str(item.get("id", item.get("_id", f"auto_{contador}")))
        nombre = item.get("nombre") or item.get("nombre_completo") or item.get("name") or f"Participante {contador}"
        categoria = item.get("categoria", "General")
        
        foto_raw = item.get("foto") or item.get("url_foto") or ""
        nombre_archivo = foto_raw.split(".")[0] if foto_raw else ""
        
        if nombre_archivo:
            foto_final = f"/static/{nombre_archivo}.png"
        else:
            foto_final = "/static/default.png"

        documento_nuevo = {
            "_id": identificador,
            "nombre_completo": nombre,
            "categoria": categoria,
            "url_foto": foto_final,
            "total_votos": 0
        }
        
        lista_documentos.append(documento_nuevo)
        await redis_client.set(f"votos:{identificador}", 0)

    if lista_documentos:
        await db.concursantes.insert_many(lista_documentos)

    return {"mensaje": f"Carga exitosa. {len(lista_documentos)} registros procesados."}

@app.post("/admin/nuevo-participante", tags=["Administracion"])
async def registrar_nuevo_participante(participante: VistaConcursanteAdministrador):
    datos = participante.model_dump(by_alias=True)
    datos["total_votos"] = 0
    
    if not datos["url_foto"] or len(datos["url_foto"]) < 3:
        datos["url_foto"] = "/static/default.png"
        
    try:
        await db.concursantes.insert_one(datos)
        await redis_client.set(f"votos:{participante.id}", 0)
    except Exception as error:
        raise HTTPException(status_code=400, detail=f"Error al registrar: {str(error)}")

    return {"mensaje": "Nuevo participante registrado"}

@app.get("/admin/dashboard-realtime", tags=["Administracion"])
async def consultar_tablero_control_tiempo_real():
    concursantes_base = await db.concursantes.find({}, {"nombre_completo": 1, "url_foto": 1}).to_list(1000)
    ranking_tiempo_real = []
    acumulado_votos_global = 0

    for item in concursantes_base:
        id_item = str(item["_id"])
        votos_redis = await redis_client.get(f"votos:{id_item}")
        conteo_actual = int(votos_redis) if votos_redis else 0
        
        acumulado_votos_global += conteo_actual
        
        ranking_tiempo_real.append({
            "id": id_item,
            "nombre": item["nombre_completo"],
            "foto": item["url_foto"],
            "votos": conteo_actual
        })
    
    ranking_tiempo_real.sort(key=lambda x: x["votos"], reverse=True)

    return {
        "total_global_votos": acumulado_votos_global,
        "detalle": ranking_tiempo_real
    }

@app.get("/admin/top-3", tags=["Reportes"])
async def obtener_podio_tres_mejores():
    pipeline = [
        {"$sort": {"total_votos": -1}},
        {"$limit": 3},
        {"$project": {"_id": 1, "nombre_completo": 1, "categoria": 1, "url_foto": 1, "total_votos": 1}}
    ]
    return await db.concursantes.aggregate(pipeline).to_list(3)

@app.get("/admin/votos-por-categoria", tags=["Reportes"])
async def agrupar_votos_por_categoria_talento():
    pipeline = [
        {"$group": {
            "_id": "$categoria",
            "total_votos_categoria": {"$sum": "$total_votos"},
            "cantidad_participantes": {"$sum": 1}
        }},
        {"$sort": {"total_votos_categoria": -1}}
    ]
    return await db.concursantes.aggregate(pipeline).to_list(100)

@app.get("/admin/sin-votos", tags=["Reportes"])
async def listar_participantes_sin_votos():
    return await db.concursantes.find({"total_votos": 0}).to_list(1000)

if __name__ == "__main__":
    import uvicorn
    print("\n================================================================")
    print("  SERVIDOR LISTO.")
    print("  Abre: http://127.0.0.1:8000")
    print("================================================================\n")
    uvicorn.run(app, host="127.0.0.1", port=8000)